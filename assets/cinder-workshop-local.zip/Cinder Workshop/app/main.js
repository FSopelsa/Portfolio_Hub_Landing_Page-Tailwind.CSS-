import { recipe } from '/recipes/tower.mjs';

const $ = id => document.getElementById(id);
let project = null, selectedId = null, previewId = null, awaitingBuild = null;
let dirty = false, busy = false, active = null, blenderReady = false, viewer = null;
let pendingReference = null, clearReference = false;
let historyKey = '';

function notice(text, error = false) { $('notice').textContent = text; $('notice').classList.toggle('error', error); }
async function api(url, method = 'GET', data) {
  const response = await fetch(url, { method, headers: { 'Content-Type': 'application/json', 'X-Workshop-Request': '1' },
    ...(data !== undefined ? { body: JSON.stringify(data) } : {}) });
  const value = await response.json();
  if (!response.ok) throw new Error(value.error ?? 'Request failed.');
  return value;
}
function controlsState() {
  $('build').disabled = busy || !!active || !blenderReady;
  $('save').disabled = busy;
  $('new-project').disabled = busy;
  $('reference-file').disabled = busy; $('clear-reference').disabled = busy;
  $('accept').disabled = busy; $('reject').disabled = busy;
  $('cancel').hidden = active?.projectId !== project?.id || !active;
}
async function action(callback) {
  if (busy) return;
  busy = true; controlsState();
  try { await callback(); } catch (error) { notice(error.message, true); }
  finally { busy = false; controlsState(); }
}
function parameters() {
  return Object.fromEntries(Object.keys(recipe.defaults).map(key => [key, key === 'palette' ? $(key).value : Number($(key).value)]));
}
function updateOutputs() {
  $('height-value').value = `${Number($('height').value).toFixed(1)} m`;
  $('radius-value').value = `${Number($('radius').value).toFixed(2)} m`;
  $('core-value').value = `${Math.round(Number($('core').value) * 100)}%`;
}
function updateReferencePreview() {
  const image = $('reference-preview');
  const saved = project?.reference?.image;
  const source = pendingReference?.dataUrl ?? (saved ? `/api/projects/${project.id}/reference?v=${encodeURIComponent(saved.updatedAt)}` : '');
  if (source) { image.src = source; image.hidden = false; }
  else { image.removeAttribute('src'); image.hidden = true; }
  $('reference-state').textContent = pendingReference ? 'Photo ready. Save project to keep it.' : saved ? 'Photo saved locally.' : 'No photo saved.';
}
async function compressReference(file) {
  if (!file?.type.startsWith('image/')) throw new Error('Choose an image file.');
  const source = await new Promise((resolve, reject) => {
    const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.onerror = () => reject(new Error('Could not read that photo.')); reader.readAsDataURL(file);
  });
  const image = await new Promise((resolve, reject) => {
    const element = new Image(); element.onload = () => resolve(element); element.onerror = () => reject(new Error('That photo could not be decoded.')); element.src = source;
  });
  const scale = Math.min(1, 1200 / Math.max(image.naturalWidth, image.naturalHeight));
  const canvas = document.createElement('canvas'); canvas.width = Math.max(1, Math.round(image.naturalWidth * scale)); canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
  canvas.getContext('2d').drawImage(image, 0, 0, canvas.width, canvas.height);
  const compressed = canvas.toDataURL('image/jpeg', 0.82);
  if (compressed.length > 2_000_000) throw new Error('Photo is still too large after compression.');
  return compressed;
}
function fillForm() {
  $('name').value = project.name; $('brief').value = project.brief;
  for (const [key, value] of Object.entries(project.parameters)) $(key).value = value;
  $('reference-facts').value = project.reference?.facts ?? ''; $('reference-estimates').value = project.reference?.estimates ?? '';
  $('reference-file').value = ''; pendingReference = null; clearReference = false; updateReferencePreview();
  dirty = false; $('save-state').textContent = 'Saved locally'; updateOutputs();
}
async function refreshList() {
  const projects = await api('/api/projects');
  $('projects').replaceChildren();
  for (const item of projects) {
    const button = document.createElement('button');
    button.className = `project-link${item.id === project?.id ? ' active' : ''}`;
    button.textContent = item.name;
    const meta = document.createElement('small'); meta.textContent = `${item.builds} build${item.builds === 1 ? '' : 's'}`; button.append(meta);
    button.onclick = () => action(async () => {
      if (dirty && !confirm('Discard unsaved changes?')) return;
      await loadProject(item.id);
    });
    $('projects').append(button);
  }
  return projects;
}
async function loadProject(id) {
  project = await api(`/api/projects/${id}`);
  selectedId = null; previewId = null; awaitingBuild = null; viewer?.clear();
  $('empty-preview').hidden = false; $('model-badge').textContent = 'NO BUILD YET'; $('mesh-stats').textContent = 'Ready when you are';
  fillForm(); await renderProject(true); await refreshList(); controlsState();
}
async function saveProject() {
  if (!$('project-form').reportValidity()) throw new Error('Check the project name.');
  const body = { name: $('name').value, brief: $('brief').value, parameters: parameters(), reference: { facts: $('reference-facts').value, estimates: $('reference-estimates').value } };
  project = await api(project ? `/api/projects/${project.id}` : '/api/projects', project ? 'PUT' : 'POST', body);
  if (pendingReference || clearReference) {
    project = await api(`/api/projects/${project.id}/reference`, 'PUT', { dataUrl: pendingReference?.dataUrl ?? null });
    pendingReference = null; clearReference = false; updateReferencePreview();
  }
  dirty = false; $('save-state').textContent = 'Saved locally'; await refreshList(); return project;
}
function artifact(build, file) { return `/api/projects/${project.id}/builds/${build.id}/${file}`; }
async function selectBuild(build) {
  selectedId = build.id;
  $('log').textContent = build.log || 'No log yet.';
  $('review').hidden = build.status !== 'ready';
  if (build.status === 'ready') {
    if (previewId !== build.id && viewer) {
      const projectId = project.id;
      const loaded = await viewer.load(artifact(build, 'asset.glb'));
      if (!loaded || project?.id !== projectId || selectedId !== build.id) return;
      previewId = build.id; $('empty-preview').hidden = true;
      $('model-badge').textContent = `BUILT / V${build.number}`;
      $('mesh-stats').textContent = `${build.report.triangles.toLocaleString()} tris · ${(build.bytes / 1024).toFixed(0)} KB`;
    }
    $('review-heading').textContent = `Version ${build.number} / ${build.parameters.palette}`;
    $('review-state').textContent = build.acceptance;
    $('review-note').value = build.reviewNote;
    $('downloads').replaceChildren();
    for (const [file, label] of [['asset.glb', 'Download GLB ↗'], ['source.blend', 'Blender source ↗']]) {
      const link = document.createElement('a'); link.href = artifact(build, file) + '?download'; link.textContent = label; link.download = file;
      $('downloads').append(link);
    }
    $('checks').replaceChildren();
    for (const check of build.report.checks) { const item = document.createElement('li'); item.textContent = check.name; $('checks').append(item); }
  } else if (build.error) notice(build.error, build.status === 'failed');
  document.querySelectorAll('.version').forEach(button => button.classList.toggle('active', button.dataset.id === selectedId));
}
async function renderProject(initial = false) {
  const nextHistoryKey = JSON.stringify([project?.id, project?.builds.map(b => [b.id, b.status, b.acceptance])]);
  const historyChanged = nextHistoryKey !== historyKey;
  historyKey = nextHistoryKey;
  if (historyChanged) $('versions').replaceChildren();
  if (!project?.builds.length) {
    $('versions').textContent = 'Each build gets its own place.'; $('review').hidden = true; $('log').textContent = 'Logs appear here.';
  } else {
    for (const build of historyChanged ? [...project.builds].reverse() : []) {
      const button = document.createElement('button'); button.className = `version ${build.acceptance} ${build.status}`;
      button.dataset.id = build.id; button.textContent = `V${build.number} · ${build.parameters.height} m`;
      const status = document.createElement('small'); status.textContent = build.status === 'ready' ? build.acceptance : build.status;
      button.append(status); button.title = build.changeNote || 'No change note';
      button.onclick = () => action(() => selectBuild(build)); $('versions').append(button);
    }
    const completed = project.builds.find(build => build.id === awaitingBuild && build.status !== 'running');
    let selected = project.builds.find(build => build.id === selectedId);
    if (initial || !selected) selected = project.builds.findLast(build => build.acceptance === 'accepted') ?? project.builds.findLast(build => build.status === 'ready') ?? project.builds.at(-1);
    if (completed) { selected = completed; awaitingBuild = null; notice(completed.status === 'ready' ? 'Build ready. Inspect it, then keep or reject it.' : completed.error, completed.status === 'failed'); await refreshList(); }
    if (selected && (selected.id !== selectedId || initial || completed)) await selectBuild(selected);
    document.querySelectorAll('.version').forEach(button => button.classList.toggle('active', button.dataset.id === selectedId));
    const running = project.builds.find(build => build.status === 'running');
    if (running) $('log').textContent = running.log || 'Starting Blender…';
    else if (selected) $('log').textContent = selected.log || 'No log.';
  }
  const accepted = project?.builds.filter(build => build.acceptance === 'accepted').length ?? 0;
  $('usage').textContent = `0 model calls · $0${accepted ? ' · $0 / accepted version' : ''}`;
}

$('project-form').addEventListener('input', event => {
  updateOutputs();
  if (event.target.id !== 'change-note') { dirty = true; $('save-state').textContent = 'Unsaved changes'; }
});
$('reference-file').addEventListener('change', event => action(async () => {
  const file = event.target.files?.[0]; if (!file) return;
  pendingReference = { dataUrl: await compressReference(file) }; clearReference = false; dirty = true; $('save-state').textContent = 'Unsaved changes'; updateReferencePreview(); notice('Photo ready. Save project to keep it.');
}));
$('clear-reference').onclick = () => action(async () => {
  if (!pendingReference && !project?.reference?.image) return;
  pendingReference = null; clearReference = !!project?.reference?.image; $('reference-file').value = ''; dirty = true; $('save-state').textContent = 'Unsaved changes'; updateReferencePreview(); notice('Photo will be removed when you save.');
});
$('project-form').onsubmit = event => {
  event.preventDefault();
  action(async () => {
    await saveProject();
    const build = await api(`/api/projects/${project.id}/builds`, 'POST', { changeNote: $('change-note').value });
    awaitingBuild = build.id; active = { projectId: project.id, buildId: build.id };
    $('build-log').open = true; $('change-note').value = ''; notice('Building your asset…'); await poll();
  });
};
$('save').onclick = () => action(async () => { await saveProject(); notice('Project saved.'); });
$('new-project').onclick = () => action(async () => {
  if (dirty && !confirm('Discard unsaved changes?')) return;
  project = null; selectedId = null; previewId = null; awaitingBuild = null; dirty = false;
  pendingReference = null; clearReference = false;
  $('project-form').reset(); updateOutputs(); $('save-state').textContent = 'New project';
  viewer?.clear(); $('empty-preview').hidden = false; $('model-badge').textContent = 'NO BUILD YET'; $('mesh-stats').textContent = 'Ready when you are'; updateReferencePreview();
  await renderProject(); await refreshList(); notice('New project. Give it a name.'); $('name').focus();
});
for (const [id, acceptance] of [['accept', 'accepted'], ['reject', 'rejected']]) $(id).onclick = () => action(async () => {
  project = await api(`/api/projects/${project.id}/builds/${selectedId}/review`, 'POST', { acceptance, reviewNote: $('review-note').value });
  await selectBuild(project.builds.find(build => build.id === selectedId)); await renderProject(); notice(`Version ${acceptance}.`);
});
$('cancel').onclick = () => action(async () => {
  await api(`/api/projects/${active.projectId}/builds/${active.buildId}/cancel`, 'POST', {}); notice('Cancelling build…');
});
$('frame').onclick = () => viewer?.frame(); $('top').onclick = () => viewer?.frame(true);
$('wireframe').onclick = () => { const enabled = $('wireframe').getAttribute('aria-pressed') !== 'true'; $('wireframe').setAttribute('aria-pressed', enabled); viewer?.setWireframe(enabled); };
window.addEventListener('beforeunload', event => { if (dirty) { event.preventDefault(); event.returnValue = ''; } });
$('scene').addEventListener('webglcontextlost', event => { event.preventDefault(); notice('Preview paused. Graphics context lost. Reload to restore it.', true); });

let polling = false;
async function poll() {
  if (polling) return;
  polling = true;
  try {
    const status = await api('/api/status'); active = status.active; blenderReady = !!status.blenderVersion;
    $('service').textContent = status.blenderVersion ?? 'Blender unavailable';
    $('build-status').textContent = active ? active.projectId === project?.id ? 'Blender is building…' : 'Another project is building…' : 'No build running';
    if (project) {
      const id = project.id;
      const fresh = await api(`/api/projects/${id}`);
      if (project?.id === id) { project = fresh; await renderProject(); }
    }
    controlsState();
  } finally { polling = false; }
}
try {
  const { createViewer } = await import('./viewer.js'); viewer = createViewer($('scene'));
} catch (error) { notice(`Preview unavailable: ${error.message}. Downloads still work.`, true); }
try {
  await poll(); const projects = await refreshList();
  if (projects.length) await loadProject(projects[0].id);
} catch (error) { notice(error.message, true); }
setInterval(() => { if (!busy) poll().catch(error => notice(error.message, true)); }, 1500);
