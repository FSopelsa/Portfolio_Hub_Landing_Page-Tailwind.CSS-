import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';

export function createViewer(canvas) {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 0.95;
  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(40, 1, 0.05, 100);
  const controls = new OrbitControls(camera, canvas);
  controls.enableDamping = true;
  controls.minDistance = 1;
  controls.maxDistance = 35;
  controls.maxPolarAngle = Math.PI * 0.49;
  scene.add(new THREE.HemisphereLight(0xe7efdf, 0x44423b, 0.9));
  const key = new THREE.DirectionalLight(0xfff3dd, 2);
  key.position.set(4, 7, 5); scene.add(key);
  const pmrem = new THREE.PMREMGenerator(renderer);
  const room = new RoomEnvironment();
  const environment = pmrem.fromScene(room, 0.04);
  scene.environment = environment.texture;
  scene.environmentIntensity = 0.65;
  room.dispose(); pmrem.dispose();
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(30, 30), new THREE.MeshStandardMaterial({ color: 0x242f28, roughness: 1 }));
  floor.rotation.x = -Math.PI / 2; floor.position.y = -0.012; scene.add(floor);
  const grid = new THREE.GridHelper(20, 20, 0x65765d, 0x3c4c3e); scene.add(grid);
  const marker = new THREE.Mesh(new THREE.BoxGeometry(0.09, 1, 0.09), new THREE.MeshStandardMaterial({ color: 0xd8ee96, roughness: 0.7 }));
  marker.position.set(-2.2, 0.5, 0); scene.add(marker);
  let model = null, wire = false, request = 0;
  function dispose(object) {
    const resources = new Set();
    object.traverse(child => {
      if (child.geometry) resources.add(child.geometry);
      for (const material of child.material ? (Array.isArray(child.material) ? child.material : [child.material]) : []) {
        resources.add(material);
        for (const value of Object.values(material)) if (value?.isTexture) resources.add(value);
      }
    });
    resources.forEach(resource => resource.dispose());
    object.removeFromParent();
  }
  function frame(top = false) {
    const box = model ? new THREE.Box3().setFromObject(model) : new THREE.Box3(new THREE.Vector3(-1, 0, -1), new THREE.Vector3(1, 4, 1));
    const center = box.getCenter(new THREE.Vector3());
    const size = box.getSize(new THREE.Vector3());
    const span = Math.max(size.y, size.x / camera.aspect, size.z / camera.aspect, 2);
    const distance = span / (2 * Math.tan(THREE.MathUtils.degToRad(camera.fov / 2))) * 1.4;
    controls.target.copy(center);
    camera.position.copy(center).add(new THREE.Vector3(...(top ? [0, 1, 0.001] : [1.15, 0.7, 1.4])).normalize().multiplyScalar(distance));
    controls.update();
  }
  function resize() {
    const { width, height } = canvas.getBoundingClientRect();
    if (!width || !height) return;
    renderer.setSize(width, height, false); camera.aspect = width / height; camera.updateProjectionMatrix();
  }
  const observer = new ResizeObserver(resize); observer.observe(canvas); resize(); frame();
  renderer.setAnimationLoop(() => { controls.update(); renderer.render(scene, camera); });
  return {
    frame,
    setWireframe(value) { wire = value; model?.traverse(child => { if (child.isMesh) for (const mat of Array.isArray(child.material) ? child.material : [child.material]) mat.wireframe = wire; }); },
    clear() { request++; if (model) dispose(model); model = null; frame(); },
    async load(url) {
      const token = ++request;
      const gltf = await new GLTFLoader().loadAsync(url);
      if (token !== request) { dispose(gltf.scene); return false; }
      if (model) dispose(model);
      model = gltf.scene;
      model.traverse(child => { if (child.isMesh) for (const mat of Array.isArray(child.material) ? child.material : [child.material]) mat.wireframe = wire; });
      scene.add(model);
      const box = new THREE.Box3().setFromObject(model);
      marker.position.x = box.min.x - 0.6;
      frame(); return true;
    },
  };
}
