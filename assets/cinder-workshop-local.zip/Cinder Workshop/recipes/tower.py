"""Trusted Cinder tower recipe v1. Adapted from Foundry's primitive/fin construction."""
import json
import math
import pathlib
import sys

import bpy
import bmesh
from mathutils import Vector


def material(name, color, metal=0.0, roughness=0.5, glow=0.0):
    mat = bpy.data.materials.new(name)
    mat.diffuse_color = (*color, 1)
    mat.use_nodes = True
    shader = mat.node_tree.nodes.get('Principled BSDF')
    shader.inputs['Base Color'].default_value = (*color, 1)
    shader.inputs['Metallic'].default_value = metal
    shader.inputs['Roughness'].default_value = roughness
    shader.inputs['Emission Color'].default_value = (*color, 1)
    shader.inputs['Emission Strength'].default_value = glow
    return mat


def finish(obj, name, mat, bevel=0):
    obj.name = name
    obj.data.materials.append(mat)
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    if bevel:
        modifier = obj.modifiers.new('Soft edges', 'BEVEL')
        modifier.width = bevel
        modifier.segments = 2
        bpy.ops.object.modifier_apply(modifier=modifier.name)
    return obj


def cylinder(name, z, radius, depth, mat, sides=48):
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.mesh.primitive_cylinder_add(vertices=sides, radius=radius, depth=depth, location=(0, 0, z))
    return finish(bpy.context.object, name, mat, min(depth * 0.12, radius * 0.025))


def fin(name, angle, height, radius, mat):
    # A closed curved shell; proportions follow the original Foundry fin method.
    vertices, faces = [], []
    radial = Vector((math.cos(angle), math.sin(angle), 0))
    tangent = Vector((-math.sin(angle), math.cos(angle), 0))
    steps = 16
    for i in range(steps + 1):
        t = i / steps
        r = radius * (0.78 - 0.56 * t * t)
        width = radius * (0.28 * (1 - t) + 0.035)
        thickness = radius * 0.055
        for across, out in [(-1, -1), (1, -1), (1, 1), (-1, 1)]:
            p = radial * (r + out * thickness) + tangent * across * width
            p.z = height * (0.14 + t * 0.86)
            vertices.append(tuple(p))
    for i in range(steps):
        for side in range(4):
            a = i * 4 + side
            b = i * 4 + (side + 1) % 4
            faces.append((a, b, b + 4, a + 4))
    faces.extend([(3, 2, 1, 0), tuple(steps * 4 + i for i in range(4))])
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(vertices, [], faces)
    mesh.update()
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
    bm.to_mesh(mesh)
    bm.free()
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)
    bpy.ops.object.select_all(action='DESELECT')
    return finish(obj, name, mat, radius * 0.012)


def main():
    params_file = pathlib.Path(sys.argv[sys.argv.index('--') + 1]).resolve()
    output = params_file.parent
    p = json.loads(params_file.read_text())
    ranges = {'height': (1, 8), 'radius': (0.4, 2), 'fins': (2, 6), 'core': (0.3, 1)}
    if set(p) != set(ranges) | {'palette'}:
        raise ValueError('Unexpected recipe parameters.')
    for key, (low, high) in ranges.items():
        if type(p[key]) not in (int, float) or not math.isfinite(p[key]) or not low <= p[key] <= high:
            raise ValueError(f'Invalid {key}.')
    if type(p['fins']) is not int or p['palette'] not in ('ember', 'teal'):
        raise ValueError('Invalid fins or palette.')

    print('STEP 1/4: Make geometry', flush=True)
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=False)
    bpy.context.scene.unit_settings.system = 'METRIC'
    bpy.context.scene.unit_settings.scale_length = 1
    h, r = p['height'], p['radius']
    iron = material('Iron', (0.055, 0.075, 0.08), 0.7, 0.34)
    copper = material('Copper', (0.55, 0.24, 0.085), 0.75, 0.3)
    ceramic = material('Ceramic', (0.42, 0.105, 0.045) if p['palette'] == 'ember' else (0.06, 0.29, 0.27), 0.1, 0.4)
    stone = material('Sandstone', (0.48, 0.40, 0.28), 0, 0.7)
    glow = material('Core', (1, 0.35, 0.035) if p['palette'] == 'ember' else (0.05, 0.8, 0.7), 0.1, 0.25, 1.8)
    cylinder('Base', h * 0.055, r, h * 0.11, iron, 6)
    cylinder('Base-trim', h * 0.09, r * 1.005, h * 0.025, copper, 6)
    cylinder('Plinth', h * 0.14, r * 0.89, h * 0.09, stone, 6)
    cylinder('Core-seat', h * 0.28, r * 0.46, h * 0.2, iron)
    for i in range(3):
        cylinder(f'Drum-band-{i + 1}', h * (0.21 + i * 0.065), r * 0.48, h * 0.018, copper)
    for i in range(p['fins']):
        angle = math.tau * i / p['fins']
        fin(f'Fin-{i + 1}', angle, h, r, ceramic)
        bpy.ops.object.select_all(action='DESELECT')
        bpy.ops.mesh.primitive_uv_sphere_add(segments=12, ring_count=8, radius=1,
            location=(math.cos(angle) * r * 0.76, math.sin(angle) * r * 0.76, h * 0.18))
        bpy.context.object.scale = (r * 0.12, r * 0.12, h * 0.045)
        finish(bpy.context.object, f'Fin-fastener-{i + 1}', copper)
    bpy.ops.object.select_all(action='DESELECT')
    bpy.ops.mesh.primitive_uv_sphere_add(segments=32, ring_count=20, radius=1, location=(0, 0, h * 0.61))
    bpy.context.object.scale = (r * p['core'] * 0.53, r * p['core'] * 0.53, h * p['core'] * 0.22)
    core = finish(bpy.context.object, 'Energy-core', glow)
    for face in core.data.polygons:
        face.use_smooth = True

    print('STEP 2/4: Check mesh', flush=True)
    meshes = [o for o in bpy.context.scene.objects if o.type == 'MESH']
    points = [o.matrix_world @ v.co for o in meshes for v in o.data.vertices]
    minimum = [min(v[i] for v in points) for i in range(3)]
    maximum = [max(v[i] for v in points) for i in range(3)]
    triangles = 0
    for obj in meshes:
        obj.data.calc_loop_triangles()
        triangles += len(obj.data.loop_triangles)
    checks = [
        {'name': 'Finite geometry', 'passed': all(math.isfinite(c) for v in points for c in v)},
        {'name': 'Ground contact', 'passed': abs(minimum[2]) < 0.001},
        {'name': 'Height matches controls', 'passed': abs(maximum[2] - h) < 0.005},
        {'name': 'Mesh budget under 25000 triangles', 'passed': 0 < triangles < 25000},
        {'name': 'Named parts and materials', 'passed': all(o.name and len(o.data.materials) for o in meshes)},
    ]
    if not all(check['passed'] for check in checks):
        raise ValueError(json.dumps(checks))
    root = bpy.data.objects.new('CinderTower', None)
    bpy.context.collection.objects.link(root)
    root['recipe'] = 'cinder-tower-v1'
    root['units'] = 'metres'
    for obj in meshes:
        obj.parent = root
    bpy.context.view_layer.update()

    print('STEP 3/4: Export GLB', flush=True)
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.export_scene.gltf(filepath=str(output / 'asset.glb'), export_format='GLB', use_selection=True,
        export_yup=True, export_apply=True, export_extras=True, export_animations=False, export_texcoords=False,
        export_cameras=False, export_lights=False)
    bpy.ops.wm.save_as_mainfile(filepath=str(output / 'source.blend'))
    report = {'recipeVersion': 1, 'blender': bpy.app.version_string, 'triangles': triangles,
        'parts': len(meshes), 'boundsBlender': {'min': minimum, 'max': maximum}, 'checks': checks,
        'limits': ['Static game mesh.', 'No print checks.', 'Visual review required.']}
    (output / 'report.json').write_text(json.dumps(report, indent=2))
    print('STEP 4/4: Done', flush=True)


if __name__ == '__main__':
    main()
