export const recipe = {
  id: 'cinder-tower', version: 1, name: 'Cinder tower',
  defaults: { height: 4, radius: 1.1, fins: 3, core: 0.7, palette: 'ember' },
  ranges: { height: [1, 8], radius: [0.4, 2], fins: [2, 6], core: [0.3, 1] },
};

export function validateParameters(value) {
  const invalid = message => Object.assign(new Error(message), { status: 400 });
  if (!value || typeof value !== 'object' || Array.isArray(value) ||
      Object.keys(value).sort().join() !== Object.keys(recipe.defaults).sort().join()) {
    throw invalid('Use the five tower controls.');
  }
  for (const [key, [min, max]] of Object.entries(recipe.ranges)) {
    if (!Number.isFinite(value[key]) || value[key] < min || value[key] > max) {
      throw invalid(`${key} must be between ${min} and ${max}.`);
    }
  }
  if (!Number.isInteger(value.fins)) throw invalid('Fin count must be a whole number.');
  if (!['ember', 'teal'].includes(value.palette)) throw invalid('Choose Ember or Teal.');
  return { ...value };
}
