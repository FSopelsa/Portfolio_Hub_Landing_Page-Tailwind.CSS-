# Cinder Workshop — local Blender edition

## Requirements

- Windows
- Node.js 22 or newer
- Blender installed locally

## Start

1. Extract this ZIP.
2. Open PowerShell in the extracted `Cinder Workshop` folder.
3. Run `npm.cmd start`.
4. Open <http://127.0.0.1:8787/>.

Stop with `Ctrl+C`. If Blender is outside `C:\Program Files\Blender Foundation`, set `$env:BLENDER_PATH` to its `blender.exe` path before starting the app.

The app keeps projects, references, and generated outputs in `data/projects/` beside `server.mjs`. The service binds to loopback and is intended for the computer running it.
