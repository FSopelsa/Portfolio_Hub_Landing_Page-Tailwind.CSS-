import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID, createHash } from 'node:crypto';
import { spawn, spawnSync } from 'node:child_process';
import { recipe, validateParameters } from './recipes/tower.mjs';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const ID = '[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}';
const projectRoute = new RegExp(`^/api/projects/(${ID})(?:/builds(?:/(${ID})(?:/(review|cancel|asset.glb|source.blend|report.json|parameters.json))?)?)?$`);
const referenceRoute = new RegExp(`^/api/projects/(${ID})/reference$`);
const REFERENCE_BYTES_MAX = 1_500_000;
const REFERENCE_BODY_MAX = 2_100_000;
const now = () => new Date().toISOString();
const fail = (message, status = 400) => Object.assign(new Error(message), { status });

export function ownedPath(root, ...parts) {
  const target = path.resolve(root, ...parts);
  const relative = path.relative(root, target);
  if (relative.startsWith('..') || path.isAbsolute(relative)) throw fail('Path is outside the project.');
  let current = root;
  for (const part of ['', ...relative.split(path.sep)]) {
    current = path.join(current, part);
    if (fs.existsSync(current) && fs.lstatSync(current).isSymbolicLink()) throw fail('Linked paths are not allowed.');
  }
  return target;
}

export function findBlender() {
  if (process.env.BLENDER_PATH) return process.env.BLENDER_PATH;
  const base = 'C:\\Program Files\\Blender Foundation';
  if (fs.existsSync(base)) {
    const names = fs.readdirSync(base).sort((a, b) => b.localeCompare(a, undefined, { numeric: true }));
    for (const name of names) {
      const executable = path.join(base, name, 'blender.exe');
      if (fs.existsSync(executable)) return executable;
    }
  }
  return 'blender';
}

function shortText(value, max, name, required = false) {
  if (typeof value !== 'string' || value.length > max || (required && !value.trim())) {
    throw fail(`${name}: ${required ? 'enter text, ' : ''}up to ${max} characters.`);
  }
  return value.trim();
}

function normalizeReference(value) {
  const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const image = source.image?.file === 'reference.jpg' && Number.isSafeInteger(source.image.bytes)
    ? { file: 'reference.jpg', mime: 'image/jpeg', bytes: source.image.bytes, updatedAt: String(source.image.updatedAt ?? '') }
    : null;
  return {
    facts: typeof source.facts === 'string' ? source.facts.slice(0, 2000) : '',
    estimates: typeof source.estimates === 'string' ? source.estimates.slice(0, 2000) : '',
    image,
  };
}

function validateReference(value, image = null) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw fail('Reference data must be an object.');
  return {
    facts: shortText(value.facts ?? '', 2000, 'Facts'),
    estimates: shortText(value.estimates ?? '', 2000, 'Estimates'),
    image,
  };
}

function decodeReference(dataUrl) {
  const match = /^data:image\/jpeg;base64,([A-Za-z0-9+/]+={0,2})$/.exec(dataUrl ?? '');
  if (!match) throw fail('Use a JPEG photo.');
  const bytes = Buffer.from(match[1], 'base64');
  if (!bytes.length || bytes.length > REFERENCE_BYTES_MAX || bytes[0] !== 0xff || bytes[1] !== 0xd8 || bytes[2] !== 0xff || bytes.at(-2) !== 0xff || bytes.at(-1) !== 0xd9) {
    throw fail('Photo data is invalid.');
  }
  return bytes;
}

export function inspectGlb(bytes) {
  if (bytes.length < 20 || bytes.toString('ascii', 0, 4) !== 'glTF' ||
      bytes.readUInt32LE(4) !== 2 || bytes.readUInt32LE(8) !== bytes.length ||
      bytes.toString('ascii', 16, 20) !== 'JSON') throw new Error('Invalid GLB header.');
  const length = bytes.readUInt32LE(12);
  if (length > bytes.length - 20) throw new Error('Invalid GLB JSON length.');
  const gltf = JSON.parse(bytes.toString('utf8', 20, 20 + length));
  if (gltf.asset?.version !== '2.0' || !gltf.meshes?.length) throw new Error('GLB has no meshes.');
  if ([...(gltf.buffers ?? []), ...(gltf.images ?? [])].some(item => item.uri)) throw new Error('GLB must be self-contained.');
  return gltf;
}

export function createWorkshop({ dataDir = path.join(ROOT, 'data'), blender = findBlender() } = {}) {
  fs.mkdirSync(dataDir, { recursive: true });
  const projectsDir = ownedPath(path.resolve(dataDir), 'projects');
  fs.mkdirSync(projectsDir, { recursive: true });
  const probe = spawnSync(blender, ['--version'], { encoding: 'utf8', timeout: 10000, windowsHide: true });
  const blenderVersion = probe.status === 0 ? probe.stdout.split(/\r?\n/)[0] : null;
  const recipeFile = path.join(ROOT, 'recipes', 'tower.py');
  let active = null;

  function projectFile(id) { return ownedPath(projectsDir, id, 'project.json'); }
  function read(id) {
    const filename = projectFile(id);
    if (!fs.existsSync(filename)) throw fail('Project not found.', 404);
    const project = JSON.parse(fs.readFileSync(filename, 'utf8'));
    project.reference = normalizeReference(project.reference);
    return project;
  }
  function save(project) {
    const filename = projectFile(project.id);
    fs.mkdirSync(path.dirname(filename), { recursive: true });
    const temp = ownedPath(projectsDir, project.id, 'project.json.tmp');
    fs.writeFileSync(temp, JSON.stringify(project, null, 2) + '\n');
    fs.renameSync(temp, filename);
  }
  function list() {
    return fs.readdirSync(projectsDir).filter(id => new RegExp(`^${ID}$`).test(id)).map(read)
      .sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
  }
  for (const project of list()) {
    let changed = false;
    for (const build of project.builds) if (build.status === 'running') {
      build.status = 'failed'; build.error = 'Build interrupted. Start a new build.'; build.finishedAt = now(); changed = true;
    }
    if (changed) save(project);
  }

  function buildProject(project, changeNote) {
    if (active) throw fail('Another build is running.', 409);
    if (!blenderVersion) throw fail('Blender not found. Set BLENDER_PATH and restart.', 503);
    const id = randomUUID();
    const directory = ownedPath(projectsDir, project.id, 'builds', id);
    fs.mkdirSync(directory, { recursive: true });
    const recipeCode = fs.readFileSync(recipeFile);
    const recipeHash = createHash('sha256').update(recipeCode).digest('hex');
    const buildRecipe = path.join(directory, 'recipe.py');
    fs.writeFileSync(buildRecipe, recipeCode);
    const build = { id, number: project.builds.length + 1, status: 'running', acceptance: 'unreviewed',
      createdAt: now(), changeNote, reviewNote: '', brief: project.brief, parameters: { ...project.parameters },
      reference: { ...project.reference, image: project.reference.image && { ...project.reference.image } },
      recipe: { id: recipe.id, version: recipe.version, sha256: recipeHash }, blenderVersion,
      usage: { modelCalls: 0, inputTokens: 0, outputTokens: 0, costUsd: 0 }, log: '' };
    fs.writeFileSync(path.join(directory, 'parameters.json'), JSON.stringify(build.parameters, null, 2));
    project.builds.push(build); project.updatedAt = now(); save(project);
    const child = spawn(blender, ['--background', '--factory-startup', '--disable-autoexec', '--python-exit-code', '1',
      '--python', buildRecipe, '--', path.join(directory, 'parameters.json')], { windowsHide: true, shell: false });
    const job = { projectId: project.id, buildId: id, child, cancelled: false, timedOut: false };
    active = job;
    const timeout = setTimeout(() => { job.timedOut = true; child.kill(); }, 120000);
    function update(edit) {
      const latest = read(project.id);
      edit(latest.builds.find(item => item.id === id));
      latest.updatedAt = now(); save(latest);
    }
    function log(chunk) { update(item => { item.log = (item.log + chunk.toString()).slice(-16000); }); }
    child.stdout.on('data', log); child.stderr.on('data', log);
    let spawnError;
    child.on('error', error => { spawnError = error; });
    child.on('close', code => {
      clearTimeout(timeout);
      try {
        update(item => {
          item.finishedAt = now();
          if (job.cancelled || job.timedOut || code !== 0 || spawnError) {
            item.status = job.cancelled ? 'cancelled' : 'failed';
            item.error = job.cancelled ? 'Build cancelled.' : job.timedOut ? 'Build exceeded two minutes.' : `Blender failed (${spawnError?.code ?? code}). See log.`;
            return;
          }
          try {
            const bytes = fs.readFileSync(ownedPath(directory, 'asset.glb'));
            inspectGlb(bytes);
            const report = JSON.parse(fs.readFileSync(ownedPath(directory, 'report.json'), 'utf8'));
            if (!report.checks?.length || report.checks.some(check => check.passed !== true)) throw new Error('Geometry checks failed.');
            if (!fs.statSync(ownedPath(directory, 'source.blend')).size) throw new Error('Blender source missing.');
            item.report = report; item.bytes = bytes.length;
            item.sha256 = createHash('sha256').update(bytes).digest('hex'); item.status = 'ready';
          } catch (error) { item.status = 'failed'; item.error = error.message; }
        });
      } catch (error) { console.error('Could not save build result:', error.message); }
      finally { if (active === job) active = null; }
    });
    return build;
  }

  async function body(req, maxLength = 32768) {
    if (req.headers['x-workshop-request'] !== '1' || req.headers['content-type']?.split(';')[0] !== 'application/json') {
      throw fail('Use the Workshop page to make changes.', 403);
    }
    const chunks = []; let length = 0;
    for await (const chunk of req) {
      length += chunk.length;
      if (length > maxLength) throw fail('Request too large.', 413);
      chunks.push(chunk);
    }
    let value;
    try { value = JSON.parse(Buffer.concat(chunks).toString()); }
    catch { throw fail('Invalid JSON.'); }
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw fail('Use a JSON object.');
    return value;
  }
  function send(res, status, value) {
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(JSON.stringify(value));
  }
  function serveFile(res, filename, download = false) {
    if (!fs.existsSync(filename) || !fs.statSync(filename).isFile()) throw fail('File not found.', 404);
    const types = { '.html': 'text/html', '.css': 'text/css', '.js': 'text/javascript', '.mjs': 'text/javascript',
      '.json': 'application/json', '.glb': 'model/gltf-binary', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.txt': 'text/plain' };
    res.writeHead(200, { 'Content-Type': types[path.extname(filename)] ?? 'application/octet-stream',
      ...(download ? { 'Content-Disposition': `attachment; filename="${path.basename(filename)}"` } : {}) });
    const stream = fs.createReadStream(filename);
    stream.on('error', () => res.destroy()); stream.pipe(res);
  }
  const server = http.createServer(async (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
    res.setHeader('X-Frame-Options', 'DENY');
    try {
      const port = server.address().port;
      if (![`127.0.0.1:${port}`, `localhost:${port}`].includes(req.headers.host)) throw fail('Local access only.', 403);
      if (req.headers.origin && req.headers.origin !== `http://${req.headers.host}`) throw fail('Origin blocked.', 403);
      if (req.headers['sec-fetch-site'] === 'cross-site') throw fail('Cross-site request blocked.', 403);
      const url = new URL(req.url, `http://${req.headers.host}`);
      const pathname = decodeURIComponent(url.pathname);
      if (pathname === '/api/status' && req.method === 'GET') return send(res, 200, { blenderVersion, recipe, active: active && { projectId: active.projectId, buildId: active.buildId } });
      if (pathname === '/api/projects') {
        if (req.method === 'GET') return send(res, 200, list().map(({ id, name, updatedAt, builds }) => ({ id, name, updatedAt, builds: builds.length })));
        if (req.method === 'POST') {
          const data = await body(req);
          const project = { id: randomUUID(), name: shortText(data.name, 80, 'Name', true), brief: shortText(data.brief, 4000, 'Brief'),
            parameters: validateParameters(data.parameters), reference: validateReference(data.reference ?? {}), createdAt: now(), updatedAt: now(), builds: [] };
          save(project); return send(res, 201, project);
        }
      }
      const referenceMatch = pathname.match(referenceRoute);
      if (referenceMatch) {
        const [, id] = referenceMatch;
        const referenceFile = ownedPath(projectsDir, id, 'reference.jpg');
        if (req.method === 'GET') {
          const project = read(id);
          if (!project.reference.image || !fs.existsSync(referenceFile)) throw fail('Reference photo not found.', 404);
          return serveFile(res, referenceFile);
        }
        if (req.method === 'PUT') {
          const data = await body(req, REFERENCE_BODY_MAX);
          const project = read(id);
          if (data.dataUrl === null) {
            fs.rmSync(referenceFile, { force: true });
            project.reference.image = null; project.updatedAt = now(); save(project);
            return send(res, 200, project);
          }
          const bytes = decodeReference(data.dataUrl);
          const temporary = ownedPath(projectsDir, id, 'reference.jpg.tmp');
          fs.writeFileSync(temporary, bytes); fs.renameSync(temporary, referenceFile);
          project.reference.image = { file: 'reference.jpg', mime: 'image/jpeg', bytes: bytes.length, updatedAt: now() };
          project.updatedAt = now(); save(project); return send(res, 200, project);
        }
        throw fail('Route not found.', 404);
      }
      const match = pathname.match(projectRoute);
      if (match) {
        const [, id, buildId, action] = match;
        let project = read(id);
        if (!pathname.includes('/builds')) {
          if (req.method === 'GET') return send(res, 200, project);
          if (req.method === 'PUT') {
            const data = await body(req);
            project = read(id);
            project.name = shortText(data.name, 80, 'Name', true); project.brief = shortText(data.brief, 4000, 'Brief');
            project.parameters = validateParameters(data.parameters);
            if (data.reference !== undefined) project.reference = validateReference(data.reference, project.reference.image);
            project.updatedAt = now(); save(project);
            return send(res, 200, project);
          }
        }
        if (!buildId && pathname.endsWith('/builds') && req.method === 'POST') {
          const data = await body(req);
          return send(res, 202, buildProject(read(id), shortText(data.changeNote, 500, 'Change note')));
        }
        let build = project.builds.find(item => item.id === buildId);
        if (!build) throw fail('Build not found.', 404);
        if (action === 'review' && req.method === 'POST') {
          const data = await body(req);
          project = read(id); build = project.builds.find(item => item.id === buildId);
          if (build.status !== 'ready') throw fail('Only completed builds can be reviewed.', 409);
          if (!['accepted', 'rejected', 'unreviewed'].includes(data.acceptance)) throw fail('Invalid review status.');
          build.reviewNote = shortText(data.reviewNote, 1000, 'Review note'); build.acceptance = data.acceptance;
          build.reviewedAt = now(); project.updatedAt = now(); save(project); return send(res, 200, project);
        }
        if (action === 'cancel' && req.method === 'POST') {
          await body(req);
          if (active?.projectId !== id || active?.buildId !== buildId) throw fail('Build is not running.', 409);
          active.cancelled = true; active.child.kill(); return send(res, 202, { message: 'Cancelling build.' });
        }
        if (req.method === 'GET' && ['asset.glb', 'source.blend', 'report.json', 'parameters.json'].includes(action)) {
          if (build.status !== 'ready') throw fail('Output is not ready.', 409);
          return serveFile(res, ownedPath(projectsDir, id, 'builds', buildId, action), url.searchParams.has('download'));
        }
      }
      if (req.method !== 'GET') throw fail('Route not found.', 404);
      if (pathname === '/') return serveFile(res, path.join(ROOT, 'app', 'index.html'));
      if (pathname === '/recipes/tower.mjs') return serveFile(res, path.join(ROOT, 'recipes', 'tower.mjs'));
      for (const prefix of ['/app/', '/showcase/']) {
        if (pathname.startsWith(prefix)) return serveFile(res, ownedPath(path.join(ROOT, prefix.slice(1)), pathname.slice(prefix.length)));
      }
      if (pathname === '/favicon.ico') { res.writeHead(204); return res.end(); }
      throw fail('Route not found.', 404);
    } catch (error) {
      const status = error.status ?? (error instanceof URIError || error instanceof SyntaxError ? 400 : 500);
      if (status === 500) console.error(error);
      if (!res.headersSent) send(res, status, { error: status === 500 ? 'Local service error. Check the terminal.' : error.message });
      else res.destroy();
    }
  });
  server.requestTimeout = 15000;
  server.on('close', () => { if (active) active.child.kill(); });
  return { server, read, list, blenderVersion };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const { server, blenderVersion } = createWorkshop();
  const port = Number(process.env.PORT ?? 8787);
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('PORT must be 1–65535.');
  server.listen(port, '127.0.0.1', () => console.log(`Cinder Workshop: http://127.0.0.1:${port}\n${blenderVersion ?? 'Blender missing. Set BLENDER_PATH.'}`));
  server.on('error', error => { console.error(error.message); process.exitCode = 1; });
  process.on('SIGINT', () => server.close());
  process.on('SIGTERM', () => server.close());
}
